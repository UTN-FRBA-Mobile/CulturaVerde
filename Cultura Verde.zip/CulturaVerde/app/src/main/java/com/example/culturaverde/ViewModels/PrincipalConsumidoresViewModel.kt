package com.example.culturaverde.ViewModels

import androidx.lifecycle.ViewModel

class PrincipalConsumidoresViewModel : ViewModel() {


}