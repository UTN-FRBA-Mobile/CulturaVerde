package com.example.culturaverde.ViewModels

import androidx.lifecycle.ViewModel

class GeoViewModel : ViewModel()  {
}