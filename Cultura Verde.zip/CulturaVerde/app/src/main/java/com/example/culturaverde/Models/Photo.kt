package com.example.culturaverde.Models

import com.google.gson.annotations.SerializedName

class Photo {

    @SerializedName("filename")
    var filename: String? = null

}