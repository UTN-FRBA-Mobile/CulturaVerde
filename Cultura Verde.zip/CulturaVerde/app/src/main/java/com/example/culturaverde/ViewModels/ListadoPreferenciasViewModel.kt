package com.example.culturaverde.ViewModels

import androidx.lifecycle.ViewModel

class ListadoPreferenciasViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}
