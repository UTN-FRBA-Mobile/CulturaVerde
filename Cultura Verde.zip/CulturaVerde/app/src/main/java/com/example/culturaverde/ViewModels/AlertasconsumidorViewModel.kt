package com.example.culturaverde.ViewModels

import androidx.lifecycle.ViewModel

class AlertasconsumidorViewModel : ViewModel() {


}