package com.example.culturaverde.ViewModels

import androidx.lifecycle.ViewModel

class AlertasproductorViewModel : ViewModel() {


}