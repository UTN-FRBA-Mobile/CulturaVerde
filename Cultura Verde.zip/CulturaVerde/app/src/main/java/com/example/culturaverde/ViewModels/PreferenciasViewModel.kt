package com.example.culturaverde.ViewModels

import androidx.lifecycle.ViewModel

class PreferenciasViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}
