package com.example.culturaverde.ViewModels

import androidx.lifecycle.ViewModel

class ReservasViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}
