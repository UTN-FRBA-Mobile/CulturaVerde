package com.example.culturaverde.ViewModels

import androidx.lifecycle.ViewModel

class CategoriasViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}
