package com.javahelps.usermanagement.service

object Model {
    data class User(val apellido: String, val contraseña: String, val nombre: String, val usuario: String)
}